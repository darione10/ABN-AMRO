from setuptools import setup

setup(name='app',
        version='0.1.0',
        author='Dario Gandini',
        description='functions for prject',
        long_description=open('README.md').read(),
        python_requires='>=3.10')