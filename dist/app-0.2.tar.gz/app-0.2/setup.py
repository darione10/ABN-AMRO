from setuptools import setup

setup(name='app',
        version='0.2',
        description='functions',
        packages=['app'])